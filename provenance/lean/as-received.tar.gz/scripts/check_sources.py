#!/usr/bin/env python3
"""Check certificate transcription; this script is not a Lean proof dependency."""
import hashlib
import json
import re
from pathlib import Path

root = Path(__file__).resolve().parent.parent
original = root / 'source-material/original'
audit = root / 'source-material/independent'
for p in original.rglob('*'):
    if p.is_file():
        assert p.read_bytes() == (audit / 'input' / p.relative_to(original)).read_bytes(), p
cert = json.loads((audit / 'verification/independent-certificate.json').read_text())
source = (root / 'RestrictedBell/Certificate.lean').read_text()
for name, field in [('coefficients', 'top_coefficients'), ('moments', 'moments'),
                    ('vector', 'negative_integer_vector')]:
    body = re.search(r'def ' + name + r' : List ℤ := \[(.*?)\]', source, re.S).group(1)
    values = [int(s.strip().strip('()')) for s in body.split(',')]
    assert values == cert[field], field
assert f'quadratic = ({cert["negative_quadratic_form"]})' in source
assert len(cert['negative_integer_vector']) == 20
assert json.loads((root / 'audit-rerun.json').read_text()) == cert
print('PASS: original files match audit input copies; Lean literals match independent certificate.')
for dirname in ['original', 'independent']:
    for p in sorted((root / 'source-material' / dirname).rglob('*')):
        if p.is_file():
            print(hashlib.sha256(p.read_bytes()).hexdigest(), p.relative_to(root))
