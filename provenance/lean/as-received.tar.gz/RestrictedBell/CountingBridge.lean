import RestrictedBell.ComputedRows.Batch8
import RestrictedBell.Coefficients

namespace RestrictedBell

/-- The last checked recurrence row matches the original coefficient certificate. -/
theorem stirling_top_certificate (k : ℕ) (hk : k < 39) :
    (stirling 5 800 (800-k) : ℤ) = Certificate.c k := by
  have h := ComputedRows.row800_correct k hk
  rw [top, if_pos (by omega)] at h
  have hdata : ∀ r : Fin 39,
      ((ComputedRows.row800[r.val]?.getD 0 : ℕ) : ℤ) = Certificate.c r.val := by
    decide
  rw [← h]
  exact hdata ⟨k, hk⟩

/-- The missing bridge: actual set-partition coefficients equal the verified
profile sums. Both sides are independently connected to the exact certificate;
the counting side uses the proved combinatorial recurrence. -/
theorem countingBell_profile_bridge (k : ℕ) (hk : k < 39) :
    (countingBell 800 5).coeff (800-k) = (profileCoefficient 800 k : ℂ) := by
  rw [countingBell_coeff_eq_stirling]
  have h : (stirling 5 800 (800-k) : ℤ) = (profileCoefficient 800 k : ℤ) :=
    (stirling_top_certificate k hk).trans (profile_coefficient k hk).symm
  exact_mod_cast h

end RestrictedBell
