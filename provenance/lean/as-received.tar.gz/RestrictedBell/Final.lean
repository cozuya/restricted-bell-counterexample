import RestrictedBell.CountingBridge
import RestrictedBell.Counterexample

namespace RestrictedBell

/-- The actual restricted Bell polynomial B_{800,≤5} has a nonreal complex root. -/
theorem restrictedBell_800_5_nonreal :
    ∃ z : ℂ, (countingBell 800 5).IsRoot z ∧ z.im ≠ 0 :=
  counterexample_of_profile_bridge countingBell_profile_bridge

/-- Counterexample to the real-rootedness assertion of Conjecture 6.4. -/
theorem realRootedness_conjecture_false : ¬ RealRootednessConjecture :=
  conjecture_false_of_counterexample restrictedBell_800_5_nonreal

end RestrictedBell
